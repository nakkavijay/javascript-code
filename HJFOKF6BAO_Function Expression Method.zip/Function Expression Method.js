// function Expressti
let message = function(){
    console.log("hellp");
    
}
message();