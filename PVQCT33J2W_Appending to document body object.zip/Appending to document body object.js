//Appending to document body Object:
let h1Element = document.createElement("h1");
h1Element.textContent = "Web Technologies";

console.log(h1Element); 
document.body.appendChild(h1Element);