let h1Element = document.createElement("h1");
h1Element.textContent = "Web Technologies";

console.log(h1Element)