// my Array pop() mrhtod
let myArray = [45,545,64,3];
let lastItem = myArray.pop();
console.log(myArray)
console.log(lastItem)