let myArray = [5,6,45,4,3];
myArray.push(34434);
console.log(myArray)