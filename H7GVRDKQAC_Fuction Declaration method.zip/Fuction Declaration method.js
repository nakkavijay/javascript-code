// function function declaration
function showMessage(){
    console.log("Hello");
    
}
showMessage();